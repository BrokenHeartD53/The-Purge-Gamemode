# DarkRP
A roleplay gamemode for Garry's Mod.

## Getting DarkRP
Please use either git or the workshop.
Manually downloading DarkRP or using SVN is possible, but not recommended.

The workshop version of DarkRP can be found here:

http://steamcommunity.com/sharedfiles/filedetails/?id=248302805

## Modifying DarkRP
Check out the wiki!

http://wiki.darkrp.com/index.php/Main_Page

Make sure to download the DarkRPMod:

https://github.com/FPtje/darkrpmodification

Do you want to create a gamemode based on DarkRP?
You probably shouldn't. If you insist, use the derived gamemode that can be downloaded here:

https://github.com/FPtje/DarkRP/releases/tag/derived

Just whatever you do, don't touch DarkRP's core files.

## Getting help
Please head to the forums!

http://forum.darkrp.com/


